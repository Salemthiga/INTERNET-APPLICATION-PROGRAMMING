from django.urls import path
from . import views
#from .views import HomeView
 
urlpatterns = [
    path('', views.index, name='index'),
    path('myenv\techBlog\templates\about.html', views.about, name='about'),
    path('post/<str:pk>', views.post, name='post'),
]